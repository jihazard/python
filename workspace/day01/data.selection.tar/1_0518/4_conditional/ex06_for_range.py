list_a = [1,2,3,4]
result = []
for num in list_a :
    result.append(num*3)
print(result)

print("=========2===========")
# 위의 for문을 간략히 한다면 
result = [num * 3 for num in list_a]
print(result)

print("=========3===========")
# 짝수에만 3을 곱한다. if조건 이용
result = [num * 3 for num in list_a if num % 2 == 0]
print(result)

print("=========4.구구단 결과 리스트에 담기===========")
result = [x*y for x in range(2, 10)
                for y in range(1, 10) ]
print(result)