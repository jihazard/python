# for 반복문과 범위를 함께 조합해서 사용합니다.
for i in range(10):
    print(str(i) + "번째 반복입니다.")