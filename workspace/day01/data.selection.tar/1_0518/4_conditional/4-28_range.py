# 범위 선언[1] - range(<숫자>)
print(range(5), list(range(5)))
print(range(10), list(range(10)))
print()

# 범위 선언[2] - range(<숫자>, <숫자>)
print(range(0, 5), list(range(0, 5)))
print(range(5, 10), list(range(5, 10)))
print()

# 범위 선언[3] - range(<숫자>, <숫자>, <숫자>)
print(range(0, 10, 2), list(range(0, 10, 2)))
print(range(0, 10, 3), list(range(0, 10, 3)))
print()