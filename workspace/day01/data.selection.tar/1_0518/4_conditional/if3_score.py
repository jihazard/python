su = 80
grade =''
print("방법1")
if su >=90 and su < 100 :
    grade = 'A'
elif su >=80 and su < 90:
    grade = 'B'
elif su >= 70 and su < 80:
    grade = 'C'
elif su >= 60 and su < 70:
    grade = 'D'
else :
    grade='F'

print(grade)
print("방법2")
if su > 100 :
    grade = 'A'
elif su >=80 :
    grade = 'B'
elif su >= 70:
    grade = 'C'
elif su >= 60 :
    grade = 'D'
else :
    grade='F'

print(grade)
print("방법3")
if 90 <= su < 100 :
    grade = 'A'
elif 80 <= su < 90:
    grade = 'B'
elif 70 <= su < 80:
    grade = 'C'
elif 60 <= su <70:
    grade = 'D'
else :
    grade='F'

print(grade)