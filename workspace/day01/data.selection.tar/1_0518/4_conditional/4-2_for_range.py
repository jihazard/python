for i in range(100):
    print("출력", i)