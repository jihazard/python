if [] :
    print("True")
else :
    print("False")
    
