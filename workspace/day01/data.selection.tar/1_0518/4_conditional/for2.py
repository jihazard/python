scores=[90, 35, 67, 45, 88]
number =0

for check in range(len(scores)) :
    if scores[check] < 60 : continue
    print("%d번 학생은 합격." % (check + 1))
   
print("---------#####-----------")

scores=[90, 35, 67, 45, 88]
number =0
for check in scores :
    number += 1
    if check < 60 : continue
    print("%d번 학생은 합격입니다." % number)
print("---------&&---------------")

scores=[90, 35, 67, 45, 88]
number =0
for check in scores :
    number += 1
    if check >= 60 :
        print("%d번 학생은 합격입니다." % number)
    else :
        print("%d번 학생은 불합격입니다." % number)


print("------------------------")
a = [(1,2), (3,4), (5,6)]
for (first, last) in a :
    print(first + last)
    print("first : {0}, last : {1}".format(first, last))
