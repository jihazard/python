coffee= 10
money = 300

print("방법2")
while True:
    money = int(input('돈을 넣어주세요: '))
    if money == 300:
        print("coffee 줍니다.")
        coffee = coffee - 1
    elif money > 300:
        print("거스름돈 %d 를 주고 커피를 줍니다." %(money - 300))
        coffee = coffee - 1 
    else :
        print("돈을 다시 돌려주고 커피를 주지 않습니다.")
        print("남은 커피의 양은 %d개 입니다." % coffee)
    if coffee <= 0:
        print("커피가 다 떨어졌습니다. 판매를 중지합니다")
        break

    # if not coffee :
    #     print("커피가 다 떨어졌습니다. 판매를 중지합니다")
    #     break

#print("방법1")
# while money :
#     print("coffee 줍니다.")
#     coffee = coffee -1
#     print("남은 커피의 양은 %d 개입니다" % coffee)
#     if coffe <= 0:
#         print('커피가 다 떨어졌습니다. 판매 중지합니다')
#         break



     
