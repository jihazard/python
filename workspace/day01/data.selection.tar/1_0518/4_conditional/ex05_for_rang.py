# 구구단 출력 방법
for i in range(1, 9):
    print("***********" , end="\t")
print(" ")
for j in range(2, 10):
    print("    %d단    " %(j), end="\t")
print(" ")
for k in range(1, 9):
    print("***********" , end="\t")
print(" ")

# ------------------------------
for j in range(1, 10):
    for i in range(2, 10) :
        print("%d * %d = %d" %(i, j, i*j), end="\t")
    
    print(' ')

print("--------------------------")
# ------------------------------

for i in range(2, 10):
    for j in range(1, 10) :
        print("%d X %d = %d" %(i, j, j*i))
    
    print(' ')

print("--------------------------")
# ------------------------------
for j in range(2, 10):
    for i in range(1, 10) :
        print(i*j, end=" ")
    print('')
