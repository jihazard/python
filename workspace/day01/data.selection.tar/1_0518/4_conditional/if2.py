money = 1
if money :
        print("택시를 타고 간다")
        print("aaa")
else :
    print("걸어간다")
    print("bbb")
    
