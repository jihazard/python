# 입력을 받습니다.
number = input("정수 입력> ")
number = int(number)
# 조건문 사용
if number > 0:
    # 양수일 때: 아직 미구현 상태입니다.
    raise NotImplementedError
else: 
    # 음수일 때: 아직 미구현 상태입니다.
    raise NotImplementedError