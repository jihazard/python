num_list=['one','two', 'three']
for i in num_list :
    print(i)

    