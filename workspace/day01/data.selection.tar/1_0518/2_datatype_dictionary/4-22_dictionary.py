# 딕셔너리를 선언합니다.
dictionary = {}

# 요소 추가 전에 내용을 출력해봅니다.
print("요소 추가 이전:", dictionary)

# 딕셔너리에 요소를 추가합니다.
dictionary["name"] = "새로운 이름"
dictionary["head"] = "새로운 정신"
dictionary["body"] = "새로운 몸"

# 반복문으로 
print("요소 추가 이후:", dictionary)