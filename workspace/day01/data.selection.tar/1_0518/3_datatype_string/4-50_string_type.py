# 변수를 선언합니다.
test = (
    "이렇게 입력해도 "
    "하나의 문자열로 연결되어 "
    "생성된답니다."
)

# 출력합니다.
print("test:", test)
print("type(test):", type(test))