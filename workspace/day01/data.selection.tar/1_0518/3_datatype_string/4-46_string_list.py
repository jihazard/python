# 문자열의 함수
str_a = "Hello Programming"
output = str_a.upper()
print("# 문자열의 함수 확인")
print("str_a:", str_a)
print("str_a.upper()의 결과:", output)
print()

# 리스트의 함수
list_a = [1, 2, 3, 4]
output = list_a.append(1)
print("# 리스트의 함수 확인")
print("list_a:", list_a)
print("list_a.append()의 결과:", output)