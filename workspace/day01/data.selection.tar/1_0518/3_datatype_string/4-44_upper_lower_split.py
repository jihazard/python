string = "Hello Programming"

output = string.upper()
print("string.upper():", output)

output = string.lower()
print("string.lower():", output)

output = string.split(" ")
print("string.split():", output)