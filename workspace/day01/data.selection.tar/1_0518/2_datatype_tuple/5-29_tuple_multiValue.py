# 함수를 선언합니다.
def test():
    return (10, 20)

# 여러 개의 값을 리턴 받습니다.
a, b = test()

# 출력합니다.
print("a:", a)
print("b:", b)