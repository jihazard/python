# 튜플을 생성합니다.
tuple_test = (10, 20, 30)

# 튜플의 요소 출력하기
print("# 튜플의 요소 출력하기")
print("tuple_test[0]:", tuple_test[0])
print("tuple_test[1]:", tuple_test[1])
print("tuple_test[2]:", tuple_test[2])
print()

# 튜플의 요소 변경하기
print("# 튜플은 요소를 변경할 수 없어요(예외가 발생합니다)")
# tuple_test[0] = 10   # 값 변경 불가

print("------------------------")
# 괄호가 없는 튜플
tuple_test = 10, 20, 30, 40
print("# 괄호가 없는 튜플의 값과 자료형 출력")
print("tuple_test:", tuple_test)
print("type(tuple_test:)", type(tuple_test))
print()

# 괄호가 없는 튜플 활용
a, b, c = 10, 20, 30
print("# 괄호가 없는 튜플을 활용한 할당")
print("a:", a)
print("b:", b)
print("c:", c)