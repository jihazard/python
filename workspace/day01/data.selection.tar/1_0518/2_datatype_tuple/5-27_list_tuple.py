# 리스트와 튜플의 특이한 사용
[a, b] = [10, 20]
(c, d) = (10, 20)

# 출력합니다.
print("a:", a)
print("b:", b)
print("c:", c)
print("d:", d)